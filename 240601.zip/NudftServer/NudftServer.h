/*
* packet definition: {0xFA, <data block>, 0xFC}
* 0xFA~0xFC: reserved for protocol
* 0xFA: Pkt header
* 0xFB: escape char, 0xFB + 0xF<D~F> denotes for 0x7<A~C>
* 0xFC: Pkt footer

* Rx data block definition:
* {<type_Transform>, <num_InputCoor>, <num_OutputCoor>, <listInputCoor>, <listInputData>, <listOutputCoor>, <sum_Bytes>}
* type@<type_Transform>: uint8
* // 0x00: NUDFT_1D
* // 0x01: NUIDFT_1D
* // 0x02: NUDFT_2D
* // 0x03: NUIDFT_2D
* // 0x04: NUDFT_3D
* // 0x05: NUIDFT_3D,
* type@<num_InputCoor>: uint64
* type@<num_OutputCoor>: uint64
* type@<listInputCoor>: {{float64, [float64, float64]} ...} // {x, [y, z]}
* type@<listInputData>: {{float64, float64} ...} // {real, imag}
* type@<listOutputCoor>: {{float64, [float64, float64]} ...} // {x, [y, z]}
* type@<sum_Bytes>: uint8 // sum of all bytes
*
* Tx data block definition:
* {<listOutputData>, <sum_Bytes>}
* type@<listOutputData>: {{float64, float64} ...} // {real, imag}
*
* range of k and xyz
* k: [-0.5, 0.5]
* xyz: [-inf, inf]
*
*/
#ifndef NUFFTSERVER_H
#define NUFFTSERVER_H

#include <QtNetwork/QTcpServer>
#include <QtNetwork/QTcpSocket>
#include <thread>
#include <complex>
#include <iostream>
#include <fstream>

#define MEMORY_LIMIT (INT32_MAX)

class NudftServer: public QTcpServer
{
    Q_OBJECT
public:
    NudftServer(QObject *parent = nullptr);
    ~NudftServer();
private:
#define FILE_CFG ("./config.ini")
    typedef struct{
        char addr[16] = {'\0'};
        int port = 0;
        int nThd = 0;
    }typeConfig;
    char addrServer[16] = {'\0'};
    uint16_t portServer;
    int64_t numThread;
    QTcpSocket *socket = nullptr;
    std::unique_ptr<std::list<uint8_t>> listRxPkt;
    std::unique_ptr<std::list<uint8_t>> listTxPkt;

    int funGetAddrPortCmd(NudftServer::typeConfig* cfg);
    int funGetAddrPortFile(NudftServer::typeConfig* cfg);
    int funSaveAddrPort(NudftServer::typeConfig* config);
    int funGetAddrPort(NudftServer::typeConfig* cfg);
    int funParsePkt(const std::list<uint8_t> *listRxPkt, std::list<uint8_t> *listTxPkt);
    int funPackData(const std::list<uint8_t>* listTxPkt, QByteArray* qByteArraySocketTxData);
    static int funNUDFT(
        const bool flagIDFT,
        const int64_t numDim,
        const int64_t lenDm0,
        const double* const arrCoorDm0,
        const double* const arrValDm0,
        const int64_t lenDm1,
        const double* const arrCoorDm1,
        double* const arrValDm1,
        const int64_t idxThread = -1);

    #define NUDFT(num_Dim, size_Dm0, arrCoorDm0, arrValDm0, size_Dm1, arrCoorDm1, arrValDm1, idxThread) \
        NudftServer::funNUDFT(false, num_Dim, size_Dm0, arrCoorDm0, arrValDm0, size_Dm1, arrCoorDm1, arrValDm1, idxThread)
    #define NUIDFT(num_Dim, size_Dm0, arrCoorDm0, arrValDm0, size_Dm1, arrCoorDm1, arrValDm1, idxThread) \
        NudftServer::funNUDFT(true, num_Dim, size_Dm0, arrCoorDm0, arrValDm0, size_Dm1, arrCoorDm1, arrValDm1, idxThread)
private slots:
    void slotNewConnection();
    void slotSocketDisconnected();
    void slotDataReceived();
};

#endif // SRV_NUDFT_H
